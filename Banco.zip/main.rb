puts 'Olá,digite um valor a depositar'
depositar = gets.chomp.to_f
saldo_atual = 0 + depositar
puts 'Olá,digite um valor a sacar'
sacar = gets.chomp.to_f
pos_saque = saldo_atual - sacar
puts 'saldo atual é ' + " #{pos_saque}"
